import sympy as sp
import numpy as np
import tools as t

head = t.read_file("admin_header")
tail  = t.read_file("admin_tail") 

sp.init_printing(use_unicode=True)


# -- Ejercicio 1 -- 

def ejer1(m):
    
    for i in range(0,m):
    
        #-- Creación del archivo .tex --
        
        # Nombre del archivo
        namefile =  "./tex/ejerc1_" + str(i)+".tex"
        
        # -- Apertura del archivo  --       
        file = open(namefile, 'w')

        # -- Escritura del preámbulo en el archivo .tex --
        file.write(str(head)) 
        
        # -- Digitación del límite --
        
        # -- Declaración del vector peusdo aleatorio de números enteros --
        a = np.random.randint(1,20,10)

        # -- Declaración de la variable simbólica --
        x  = sp.Symbol('x')
       
        # -- Uso del comando Limit para la escritura del límite --
        expr = sp.Limit( ( x-a[0]**2 ) / ( sp.sqrt(x) - a[0]), x, a[0]**2,'+-')            
        
        # -- Escritura del límite en el archivo .tex --            
        file.write('$  \displaystyle' + str(sp.latex(expr)) + '$ \\\\ \n ')
        
        # -- Respuesta al límite --        
        
        # -- Uso del comando limit para el cálculo del resultado --
        resp = sp.limit( ( x-a[0]**2 ) / ( sp.sqrt(x) - a[0]), x, a[0]**2,'+-')    
        
        # -- Escritura del resultado límite en el archivo .tex --            
        file.write('\\textit{Respuesta}: $'  + str(sp.latex(resp)) +  '$  \\\\ \n ')
        
        # -- Escritura final en el archivo .tex --             
        file.write(str(tail))      

        # -- Cierre del archivo .tex --           
        file.close()
        
       

# -- Ejercicio 2 -- 

def ejer2(m):
    
    for i in range(0,m):
    
        #-- Creación del archivo .tex --
        
        # Nombre del archivo
        namefile =  "./tex/ejerc2_" + str(i)+".tex"
        
        # -- Apertura del archivo  --       
        file = open(namefile, 'w')

        # -- Escritura del preámbulo en el archivo .tex --
        file.write(str(head)) 
        
        
        # -- Declaración de los vectores pseudo aleatorios  de números enteros --
        a = np.random.randint(3,7,1)        
        b = np.random.randint(-2,3,1)        
        
        # -- Declaración de la variable simbólica --
        x  = sp.Symbol('x')

        # Declaración de la funcion f
        fun  = (a[0] * x - a[0]**2 ) / (x**2 + (b[0] - a[0])*x - a[0]*b[0])

        # Encabezados del ejercicio              
        file.write('Analice la continuidad de la función $f$ con criterio de asociación:\n')    
        file.write('\\begin{center} \n')
        file.write('$\displaystyle f(x) := ' + str(sp.latex(fun)) + '$')
        file.write('\end{center}\n')

          
        # Respuesta al ejercicio        
        file.write('\\begin{center}\n')
        file.write('\\textbf{Respuesta}\n')
        file.write('\end{center}\n')
                
        file.write('\\begin{enumerate}\n')
        
        #  -- Dominio de la función --     
        file.write('\item El dominio de la función es ${\\rm I\!R } - \{')
        file.write( str(a[0]) + ',' + str(-1*b[0]) + '\}$\n')
        
        # -- Cálculo de los límites --
        simb = str(sp.latex(sp.Limit(fun, x, a[0],'+-'))) 
        res = str(sp.latex(sp.limit(fun, x, a[0],'+-')))  
        
        # -- Respuesta para x=a --
        file.write('\item $f$ posee una discontinuidad evitable en ')
        file.write('$ x = ' + str(a[0])+'$ pues: \n')
        file.write('\\begin{center}')
        file.write('$ \displaystyle'+ simb + ' $ =' + '$ \displaystyle' + res + '$.\n' )
        file.write('\end{center}\n')
        
        
        # -- Respuesta para x=b --
        simb = str(sp.latex(sp.Limit(fun, x, -1*b[0],'-')))         
        file.write('\item $f$ posee una discontinuidad inevitable en ')
        file.write('$ x = ' + str(-1*b[0])+'$ pues: \n ')
        file.write('\\begin{center}')
        
        res = str(sp.latex(sp.limit(fun, x, -1*b[0],'-')))  
        file.write('$ \displaystyle'+ simb + ' $ =' + '$ \displaystyle' + res + '$ \n' )                
        
        simb = str(sp.latex(sp.Limit(fun, x, -1*b[0],'+')))                         
        res = str(sp.latex(sp.limit(fun, x, -1*b[0],'+')))  
        
        file.write(' y  $ \displaystyle'+ simb + ' $ =' + '$ \displaystyle' + res + '$. \n' )        
        file.write('\end{center}')
        
        file.write('\\end{enumerate}')
        
        # -- Escritura final en el archivo .tex --             
        file.write(str(tail))      

        # -- Cierre del archivo .tex --           
        file.close()


# -- Generacion de 10 ejercicios .tex (descomentar uno a la vez). Correr el archivo --      
m=10 
#ejer1(m)
ejer2(m)

# -- Ejecutar en la terminal para general los archivos .pdf: --

# GNU-Linux
# for i in *.tex; do pdflatex $i; done && rm *.aux *.log *.tex

# MS Windows
#  FOR \%i IN (*.tex) DO pdflatex %i &&  DEL *.log *.aux *.out





